/****************************************************************************
 *
 *   Copyright (c) 2015 Crossline Drone Project Team. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name CLDrone nor Crossline Drone nor the names of its c
 *    ontributors may be used to endorse or promote products derived from 
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 ****************************************************************************/
 /****************************************************************************
               **************** 改进内容 ****************

1. 将键盘调整功能改为 按着键不放，一直以某速度飞行，松开即定点悬停
2. 增加 10次未检测到mark，自动进入定点悬停模式的条件判断，必须在 offboard 模式下才有效
3. 高度小于阈值时，检测不到mark，水平位置不调整，继续降落
4. 高度低于阈值（接近地面），继续降落，定时结束后锁定飞机

10.25
   修改 PID 参数读取方式为直接读取型，替代节点句柄型
 ****************************************************************************/
#include <ros/ros.h>
#include <geometry_msgs/Point.h>
#include <sensor_msgs/Range.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/TwistStamped.h>
#include <geometry_msgs/PoseArray.h>
#include <tf/tf.h>
#include <tf/transform_datatypes.h>
#include <mavros_msgs/CommandBool.h>
#include <mavros_msgs/State.h>
#include <keyboard/Key.h>

using namespace std;

//geometry_msgs::TwistStamped vs;
geometry_msgs::TwistStamped vs_body_axis;
//ros::Publisher local_pos_pub_;
//ros::Publisher enuSetLocoalPositionPublisher;
ros::Publisher bodyAxisVelocityPublisher;
ros::ServiceClient arming_client;
geometry_msgs::PoseStamped uavPose;
double uavRollENU, uavPitchENU, uavYawENU;

double err_x, err_y, err_z;
double err_roll, err_pitch, err_yaw;

double last_err_x, last_err_y, last_err_z;
double last_err_roll, last_err_pitch, last_err_raw;
double last_timestamp;

double xyP, xyI, xyD, zP, zI, zD, xyForward;
double yawP, yawD, yawForward;

double dt;

// 主点坐标
# define U0 339.0
# define V0	194.0
// 归一化焦距
# define FOCAL_X 518.0
# define FOCAL_Y 515.0

float uav_init_altitude = 0.0;
float uav_altitude = 0.0;     
float uav_x_distance = 0.0;
float uav_y_distance = 0.0;

bool flag_offboard_mode = false;
bool flag_enter_position_hold = false;
bool flag_enter_manual_adjust = false;

// 判断飞行模式
mavros_msgs::State current_state;
void stateReceived(const mavros_msgs::State::ConstPtr& msg) 
{
    static int flag = 0;
    current_state = *msg;

    if (current_state.mode == "OFFBOARD")
    {
        if(flag == 0)
        {
            ROS_INFO_STREAM("Offboard Mode"); 
            flag = 1;         
        }

        flag_offboard_mode = true;
    }
    else
    {
        flag_offboard_mode = false;
        flag = 0;   
    }
}

// 无人机位置和姿态，From 内部传感器
void uavPoseReceived(const geometry_msgs::PoseStampedConstPtr& msg)
{   
    //uavPose = *msg;   
    uavPose.pose.position.x = msg->pose.position.x;
    uavPose.pose.position.y = msg->pose.position.y;
    uavPose.pose.position.z = msg->pose.position.z;
    uavPose.pose.orientation.x = msg->pose.orientation.x;
    uavPose.pose.orientation.y = msg->pose.orientation.y;
    uavPose.pose.orientation.z = msg->pose.orientation.z;
    uavPose.pose.orientation.w = msg->pose.orientation.w;
    
    // Using ROS tf to get RPY angle from Quaternion
    tf::Quaternion quat;
    tf::quaternionMsgToTF(uavPose.pose.orientation, quat);  
    tf::Matrix3x3(quat).getRPY(uavRollENU, uavPitchENU, uavYawENU);
//  ROS_INFO("local_position/local: Pos:[%0.3f, %0.3f, %0.3f], RPY:[%0.3f, %0.3f, %0.3f]", uavPose.pose.position.x, uavPose.pose.position.y, uavPose.pose.position.z,uavRollENU*180/3.1415926, uavPitchENU*180/3.1415926, uavYawENU*180/3.1415926);
    //ROS_INFO("Current UAV angles: roll=%0.3f, pitch=%0.3f, yaw=%0.3f", uavRollENU*180/3.1415926, uavPitchENU*180/3.1415926, uavYawENU*180/3.1415926);  
}

// 从超声传感器获取飞机高度,并计算高度偏差 
void uavAltitudeReceived(const sensor_msgs::Range& msg)
{
    static int flag = 0;  
    if (msg.range > 0.28f)
    {
        if(flag == 0)
        {
        	uav_init_altitude = msg.range;
    	    flag = 1;
        }
        else
        {           
            uav_altitude = msg.range;
        }

        //cout << "uav_altitude = " << uav_altitude << endl;
        // 首先控制高度恒定，z轴偏差为目前高度与初始高度之差
        err_z = uav_init_altitude - uav_altitude;
    }
}

// 获取 aruco 坐标中心，并计算无人机相对 x y 距离 
void markerCenterReceived(const geometry_msgs::Point& msg)
{	
	static int flag_not_found_mark = 0;
    static geometry_msgs::Point markcenter;
	// 获取 aruco 坐标中心
	markcenter.x = msg.x;
	markcenter.y = msg.y;

    // 当标志中心坐标有效时，计算无人机相对标志 x y 距离
    if (markcenter.x > 0.01f && markcenter.y > 0.01f) 
    {
    	uav_x_distance = uav_altitude*(markcenter.x-U0)/FOCAL_X;
    	uav_y_distance = uav_altitude*(markcenter.y-V0)/FOCAL_Y;

    	//cout << "uav_x_distance = " << uav_x_distance << endl;
    	//cout << "uav_y_distance = " << uav_y_distance << endl;

        // 将无人机与mark在 x y z 方向的距离偏差，分别表示为err_ ,便于控制部分的理解
    	err_x = uav_x_distance;
    	err_y = uav_y_distance;
        
        // // 误差很小时，设置误差为0，不再调整
        // if (fabs(err_x) < 0.16*uav_altitude) //0.1
        //     err_x = 0.0;
        // if (fabs(err_y) < 0.16*uav_altitude)
        //     err_y = 0.0;

        //一旦发现标志，将未发现mark的计数标志复位0
        flag_not_found_mark = 0;
    } 
    // offboard 模式下，高度大于0.5m？，连续 10次 未发现标志，认为目标丢失，进入定点模式
    // 高度小于0.5m？，由于 mark 占图像大部分，飞机晃动，mark很容易出视野，识别失败，此时 继续降落
    else
    {
        flag_not_found_mark++;
        if (flag_offboard_mode && (flag_not_found_mark > 10))
        {           
            if(uav_altitude > 1.8)
            {
                ROS_INFO_STREAM("Fail to found mark, enter Position Hold");
                flag_enter_position_hold = true;
            }
            else
            {
                err_x = 0.0;
                err_y = 0.0;
                last_err_x = 0.0;
                last_err_y = 0.0;
            }

            flag_not_found_mark = 0;

        }
    }
}

// 飞机速度控制
void landingVelocityControl()
{
    vs_body_axis.header.seq++;
	vs_body_axis.header.stamp = ros::Time::now();

	dt = ros::Time::now().toSec() - last_timestamp;

    if ((fabs(err_x) < 0.2*uav_altitude) && (fabs(err_y) < 0.2*uav_altitude))
    {
        vs_body_axis.twist.linear.z = -0.2;
    }

    // // 当x，y误差很小时，逐渐降落
    // if ((fabs(err_x) < 0.01) && (fabs(err_y) < 0.01)) 
    // {
    //     // if(uav_altitude > 0.5) 
    //        vs_body_axis.twist.linear.z = -0.2;
    //     // else
    //     // vs_body_axis.twist.linear.z = -0.1; 
    // }
    else
    {
        vs_body_axis.twist.linear.z = 0.0;
    }


    // 计算速度控制量  ！！！图像坐标系 x y轴 与速度控制坐标系 x y轴相反
    // P控制
    ////vs_body_axis.twist.linear.x = err_y * xyP ;
    ////vs_body_axis.twist.linear.y = err_x * xyP ;  
    // vs_body_axis.twist.linear.z = err_z * zP ;

    // PD控制
    vs_body_axis.twist.linear.x = err_y * xyP + (err_y - last_err_y) / dt * xyD;
    vs_body_axis.twist.linear.y = err_x * xyP + (err_x - last_err_x) / dt * xyD;

if(uav_altitude < 1.0) 
{
    // PD控制
    vs_body_axis.twist.linear.x = err_y * xyP * 1.5 + (err_y - last_err_y) / dt * xyD;              
    vs_body_axis.twist.linear.y = err_x * xyP * 1.5 + (err_x - last_err_x) / dt * xyD;
}

    // vs_body_axis.twist.linear.z = err_z * zP + (err_z - last_err_z) / dt * zD;
    // vs_body_axis.twist.linear.z = 0;
    // vs_body_axis.twist.angular.x = 0;
    // vs_body_axis.twist.angular.y = 0;
    // vs_body_axis.twist.angular.z = (- err_yaw) * yawP + (- err_yaw - last_err_raw) /dt * yawD;

     last_err_x = err_x;
     last_err_y = err_y;
     //last_err_z = err_z;
     //last_err_raw = - err_yaw;
     last_timestamp = ros::Time::now().toSec();
}


/***************** 键盘控制 按下一直飞行 松开停止********************/
void sendflightCommand(const keyboard::Key &key)
{
   vs_body_axis.header.seq++;
   vs_body_axis.header.stamp = ros::Time::now();

   switch (key.code)
   {
        case 'q':
        {
            ROS_INFO_STREAM("manual quit, enter Position Hold");
            flag_enter_position_hold = true;
            break;
        }

        case 'p':
        {
            flag_enter_position_hold = false;
            flag_enter_manual_adjust = false;
            ROS_INFO_STREAM("manual recover Offboard Mode");
            break;
        }

        case 'm':
        {
            flag_enter_manual_adjust = true;
            ROS_INFO_STREAM("enter manual adjust");
            break;
        }

        case 'w':
        {
            ROS_INFO_STREAM("up");
            vs_body_axis.twist.linear.z = 0.2;
            break;
        }
        case 's':
        {
            ROS_INFO_STREAM("down");
            vs_body_axis.twist.linear.z = -0.2;
            break;
        }
        case 'j':
        {
            ROS_INFO_STREAM("left");
            vs_body_axis.twist.linear.y = -0.2;
            break;
        }
        case 'l':
        {
            ROS_INFO_STREAM("right");
            vs_body_axis.twist.linear.y = 0.2;
            break;
        }
        case 'i':
        {
            ROS_INFO_STREAM("forward");
            vs_body_axis.twist.linear.x = -0.2;
            break;
        }
        case 'k':
        {
            ROS_INFO_STREAM("backward");
            vs_body_axis.twist.linear.x = 0.2;
            break;
        }
        case 'z':
        {
            vs_body_axis.twist.linear.x = 0.0;
            vs_body_axis.twist.linear.y = 0.0;
            vs_body_axis.twist.linear.z = 0.0;
            vs_body_axis.twist.angular.z = 0.0;
            break;
        }

        default:
        {
            
        }
    }
}

void sendholdCommand(const keyboard::Key &key)
{
   vs_body_axis.header.seq++;
   vs_body_axis.header.stamp = ros::Time::now();

   switch (key.code)
   {
        case 'w':
        {
            ROS_INFO_STREAM("quit up");
            vs_body_axis.twist.linear.z = 0.0;
            break;
        }
        case 's':
        {
            ROS_INFO_STREAM("quit down");
            vs_body_axis.twist.linear.z = 0.0;
            break;
        }
        case 'j':
        {
            ROS_INFO_STREAM("quit left");
            vs_body_axis.twist.linear.y = 0.0;
            break;
        }
        case 'l':
        {
            ROS_INFO_STREAM("quit right");
            vs_body_axis.twist.linear.y = 0.0;
            break;
        }
        case 'i':
        {
            ROS_INFO_STREAM("quit forward");
            vs_body_axis.twist.linear.x = 0.0;
            break;
        }
        case 'k':
        {
            ROS_INFO_STREAM("quit backward");
            vs_body_axis.twist.linear.x = 0.0;
            break;
        }

        default:
        {
            
        }
    }
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "velocity_marker_land_node");
    ros::NodeHandle nh;

    mavros_msgs::CommandBool arm_cmd;
    arm_cmd.request.value = false;
    int flag_time = 0;
    int flag_low_altitude = 0;

    ros::Time time_disarm(0);

    printf("------------landing control node running successfully-------------\n");

    bodyAxisVelocityPublisher = nh.advertise<geometry_msgs::TwistStamped>("/mavros/setpoint_velocity/cmd_vel",10);
    //enuSetLocoalPositionPublisher = nh.advertise<geometry_msgs::PoseStamped>("/mavros/setpoint_position/local", 1000);
    //local_pos_pub_ = nh.advertise<geometry_msgs::PoseStamped>("/mavros/vision_pose/pose", 1000);
    //ros::Subscriber markerPoseAprilSubscriber = nh.subscribe("/tag_detections_pose", 1000, markerPoseAprilReceived);
    ros::Subscriber stateSubscriber = nh.subscribe("mavros/state", 10, stateReceived);
    ros::Subscriber markerCenterSubscriber = nh.subscribe("/aruco_single/pixel",1000,markerCenterReceived);  
    ros::Subscriber uavPoseSubscriber = nh.subscribe("/mavros/local_position/pose", 1000, uavPoseReceived);
    ros::Subscriber uavAltitudeSubscriber = nh.subscribe("/mavros/px4flow/ground_distance", 1000, uavAltitudeReceived);
    ros::Subscriber flightcommandSubscriber = nh.subscribe("/keyboard/keydown",1,sendflightCommand);
    ros::Subscriber holdcommandSubscriber = nh.subscribe("/keyboard/keyup",1,sendholdCommand);
    arming_client = nh.serviceClient<mavros_msgs::CommandBool>("mavros/cmd/arming");

    last_err_x = 0;
    last_err_y = 0;
    last_err_z = 0;
    last_err_raw = 0;

    // 设置 PID 值
    // xyP = 0.6; // 暂定
    // xyD = 0.03;
    // zP = 0.4;
    // zD = 0.03;

    // yawP = 0.05;
    // yawD = 0.03;

    // 获取 PID 参数值
    ros::param::param("~xyP", xyP, 0.0);
    ros::param::param("~xyI", xyI, 0.0);
    ros::param::param("~xyD", xyD, 0.0);
    ros::param::param("~zP", zP, 0.0);
    ros::param::param("~zI", zI, 0.0);
    ros::param::param("~zD", zD, 0.0);

    cout << "got xyP = " << xyP << endl;
    cout << "got xyD = " << xyD << endl;

    ros::Rate loopRate(50.0);
    while(ros::ok())
    {	 
	  if(flag_offboard_mode)
      {
          // 高度大于0.35m，正常控制飞行
          if(uav_altitude >= 0.35)
          {             
              // 切换到 offboard 模式，且未进入位置保持状态
              if(flag_offboard_mode && !flag_enter_position_hold)
              {
                    landingVelocityControl();   
                    ROS_INFO_STREAM("Offboard auto control");     
              }
              // 在 offboard 模式下，进入位置保持状态, 未进入手动调节模式
              else if(flag_enter_position_hold && !flag_enter_manual_adjust)
              {
                    ROS_INFO_STREAM("Position hold control");
                    vs_body_axis.header.seq++;
	            vs_body_axis.header.stamp = ros::Time::now();
                    vs_body_axis.twist.linear.x = 0;
                    vs_body_axis.twist.linear.y = 0;
                    vs_body_axis.twist.linear.z = 0;
                    vs_body_axis.twist.angular.z = 0;
              }

            flag_low_altitude = 0;
          }

          // 高度小于 0.35m，继续降落，1s 后飞机锁定(防止超声波数据出错，要求低高度预警连续触发3次)
          else
          {     
               flag_low_altitude++;
               if(flag_low_altitude > 2)  
               {        
                   flag_low_altitude = 3;
		   vs_body_axis.header.seq++;
	           vs_body_axis.header.stamp = ros::Time::now();
                   vs_body_axis.twist.linear.x = 0;
                   vs_body_axis.twist.linear.y = 0;
                   vs_body_axis.twist.linear.z = -0.2;

                   if (flag_time == 0)
                   {        
                        time_disarm = ros::Time::now();
                        flag_time = 1;
                   }

                   if ((ros::Time::now() - time_disarm) > ros::Duration(1.0))
                   {
                        if( arming_client.call(arm_cmd) && arm_cmd.response.success)
                        {
                            ROS_INFO("Vehicle disarmed");
                            return 0;
                        }
                   }
               }
          }
      }

      //发布速度控制量
      bodyAxisVelocityPublisher.publish(vs_body_axis);
      
	  ros::spinOnce();
  	  loopRate.sleep();
    }

    return 0;
}
