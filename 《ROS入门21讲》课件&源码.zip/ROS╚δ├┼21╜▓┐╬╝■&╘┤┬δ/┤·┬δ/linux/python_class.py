class A:
    i = 10
    def test(self):
        print self.i
        
a = A()
a.test()
