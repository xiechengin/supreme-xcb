for a in range(5, 10):
    if a < 10:
        print 'a = ', a
        a += 1
    else:
        break
