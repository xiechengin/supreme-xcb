a = 5

while a < 10:
    print 'a = ', a
    a += 1
