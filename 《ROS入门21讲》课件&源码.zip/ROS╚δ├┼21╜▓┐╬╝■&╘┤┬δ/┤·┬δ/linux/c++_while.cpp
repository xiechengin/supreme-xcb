#include <iostream>
using namespace std;

int main()
{
    int a = 5;
    
    while(a < 10)
    {
        cout << "a = "  << a << endl;
        a++;
    }
    
    return 0;
}
