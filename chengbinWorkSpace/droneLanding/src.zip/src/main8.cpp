/*
 * @brief: 校准相机(Camera Calibration) Demo,需要.yml相机参数文件
 * @Version: 
 * @Autor: shuike
 * @Date: 2020-12-31 12:32:28
 * @LastEditors: shuike
 * @LastEditTime: 2021-01-04 13:44:34
 * @FilePath: /droneLanding/src/main8.cpp
 * @refrence: https://blog.csdn.net/qq_33446100/article/details/89192005
 */


#include <opencv2/highgui.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/aruco.hpp>
#include <opencv2/aruco/dictionary.hpp>
#include <opencv2/aruco/charuco.hpp>
#include <opencv2/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/opencv.hpp>
#include <vector>
#include <iostream>
 
using namespace std;
using namespace cv;
 
int main()
{
	cv::VideoCapture inputVideo(0);//外置摄像头，自带摄像头请使用0
	//VideoWriter writer("VideoTest.avi", VideoWriter::fourcc('M', 'J', 'P', 'G'), 25.0, Size(640, 480));
	cv::Mat cameraMatrix, distCoeffs; // 相机参数
 
	FileStorage fs("/Users/shuike/Desktop/work/svn/droneLanding/build/mycalibrationfile.yml", FileStorage::READ);//读取相机参数
	if (!fs.isOpened())
	{
		cout << "Could not open the configuration file!" << endl;
		exit(1);
	}
	fs["camera_matrix"] >> cameraMatrix;
	fs["distortion_coefficients"] >> distCoeffs;
	fs.release();
	cout << cameraMatrix << endl;
	cout << distCoeffs << endl;
 
	Ptr<aruco::Dictionary> dictionary =
		aruco::getPredefinedDictionary(cv::aruco::DICT_4X4_50);//创建字典
 
	while (inputVideo.grab()) {
		unsigned int i = 0;
		cv::Mat image, imageCopy;
 
		inputVideo.retrieve(image);
		image.copyTo(imageCopy);
 
		std::vector<int> ids;
		std::vector<std::vector<cv::Point2f> > corners;
 
		cv::aruco::detectMarkers(image, dictionary, corners, ids);// 检测markers
 
		if (ids.size() > 0) {
			cv::aruco::drawDetectedMarkers(imageCopy, corners, ids);
			vector< Vec3d > rvecs, tvecs;//得到旋转矢量以及平移矢量
			cv::aruco::estimatePoseSingleMarkers(corners, 100, cameraMatrix, distCoeffs, rvecs, tvecs); 
			
			for (i = 0; i < ids.size(); i++)
				cv::aruco::drawAxis(imageCopy, cameraMatrix, distCoeffs, rvecs[i], tvecs[i], 50);// 画方向轴
			//writer << imageCopy;
		}
 
		cv::imshow("out", imageCopy);
 
		char key = (char)cv::waitKey(20);
		if (key == 'b') break;
	}
 
	return 0;
}