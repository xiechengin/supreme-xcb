#include <opencv2/aruco.hpp>
#include <opencv2/aruco/charuco.hpp>

#include <opencv2/opencv.hpp>

int main(int argc, char **argv)
{
	

}